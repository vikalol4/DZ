
def task1():
    products = {1: 'milk', 2: 'oranges', 3:'bananas', 4: 'bread', 5: 'cheese', 6: 'eggs'}
    k = int(input('Введите ключ продукта: '))
    print(products[k])

def task2():
    product = {'name': 'cookies','country': 'China', 'calories': 500}
    weight = int(input('Введите вес: '))
    calories = int(input('Введите калории: '))
    country = input('Введите страну: ')
    product['baked'] = True
    product['weight'] = weight
    product['country'] = country
    product['calories'] = calories
    print(product)

def task3():
    bank_account = {'Иванов И.И.': 3500000, 'Петров П.П.': 32000, 'Сидоров С.С.': 5400000, 'Васильев В.В.': 0, 'Сергеев С.С': 3500000}
    keys = list(bank_account.keys())
    values = list(bank_account.values())
    print(keys)
    print(values)

def task4():
    scores = {35, 37, 13, 18, 34, 19, 6, 0, 14, 9}
    print(len(scores))
    num = int(input('Введите балл: '))
    print(num in scores)
    scores.remove(num) if num in scores else scores.pop()
    print(scores)

def task5():
    A = {1, 2, 3, 4, 5}
    B = {1, 3, 5, 7, 9}
    print(A | B)
    print(A & B)
    print(A - B)
    print(A ^ B)
    print(A == B)

def task6():
    letters = {'a': 97, 'b': 98, 'c': 99, 'd': 100, 'e': 101, 'f': 102, 'g': 103, 'h': 104, 'i': 105, 'j': 106, 'k': 107, 'l': 108, 'm': 109, 'n': 110, 'o': 111, 'p': 112, 'q': 113, 'r': 114, 's': 115, 't': 116, 'u': 117, 'v': 118, 'w': 119, 'x': 120, 'y': 121, 'z': 122}
    n = int(input('Введите количество чисел: '))
    result = [value for value in letters.values() if value % 2 == 0][:n]
    print(result)

if __name__ == '__main__':
    print('Проект с решениями задач Python5')
